from boggle import Boggle

boggle_game = Boggle()
