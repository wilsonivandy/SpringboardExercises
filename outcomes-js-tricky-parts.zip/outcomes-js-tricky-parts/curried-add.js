function curriedAdd(total) {

}

module.exports = { curriedAdd };
