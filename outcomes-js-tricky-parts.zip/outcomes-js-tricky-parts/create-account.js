function createAccount(pin, amount) {

}

module.exports = { createAccount };
